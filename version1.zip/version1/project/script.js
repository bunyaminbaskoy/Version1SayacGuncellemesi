document.addEventListener('DOMContentLoaded', function() {
    // Giriş Kontrolü
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const currentPage = window.location.pathname;
    const loginPage = '/login.html';

    // Eğer giriş sayfasında değilsek ve giriş yapılmamışsa, giriş sayfasına yönlendir
    if (currentPage !== loginPage && !isLoggedIn) {
        window.location.href = loginPage;
        return;
    }

    // Giriş Formu İşleme
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            // Belirtilen kullanıcı adı ve şifre kontrolü
            if (username === 'ss' && password === '2121') {
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('username', username);
                window.location.href = 'index.html';
            } else {
                alert('Kullanıcı adı veya şifre hatalı!');
            }
        });
    }

    // Mantar Pano Kişiselleştirme
    const boardColor = document.getElementById('boardColor');
    const noteColor = document.getElementById('noteColor');
    const noteShape = document.getElementById('noteShape');
    const boardContainer = document.querySelector('.board-container');
    const notes = document.querySelectorAll('.note');

    if (boardColor) {
        boardColor.addEventListener('input', function(e) {
            boardContainer.style.backgroundColor = e.target.value;
        });
    }

    if (noteColor) {
        noteColor.addEventListener('change', function(e) {
            notes.forEach(note => {
                note.style.backgroundColor = e.target.value;
            });
        });
    }

    if (noteShape) {
        noteShape.addEventListener('change', function(e) {
            notes.forEach(note => {
                note.className = 'note';
                if (e.target.value !== 'square') {
                    note.classList.add(e.target.value);
                }
            });
        });
    }

    // Not Ekleme
    const addNoteBtn = document.querySelector('.add-note-btn');
    const noteTextarea = document.querySelector('.add-note textarea');
    const notesContainer = document.querySelector('.notes-container');

    if (addNoteBtn && noteTextarea && notesContainer) {
        addNoteBtn.addEventListener('click', function() {
            const noteText = noteTextarea.value.trim();
            if (noteText) {
                const note = document.createElement('div');
                note.className = 'note';
                if (noteShape && noteShape.value !== 'square') {
                    note.classList.add(noteShape.value);
                }
                
                note.style.backgroundColor = noteColor ? noteColor.value : '#fff9c4';
                note.style.transform = `rotate(${Math.random() * 6 - 3}deg)`;
                
                note.innerHTML = `
                    <p>${noteText}</p>
                    <span class="delete-note">×</span>
                `;
                
                notesContainer.appendChild(note);
                noteTextarea.value = '';
                
                // Yeni not için silme işlevselliği
                const deleteBtn = note.querySelector('.delete-note');
                deleteBtn.addEventListener('click', function() {
                    note.remove();
                });
            }
        });
    }

    // Mevcut notları silme
    document.querySelectorAll('.delete-note').forEach(btn => {
        btn.addEventListener('click', function() {
            this.parentElement.remove();
        });
    });
});